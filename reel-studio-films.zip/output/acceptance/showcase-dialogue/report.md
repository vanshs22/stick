# Production report: The padlock lie

- video: showcase-dialogue.mp4, 22.9 s, 1080x1920
- style: editorial-sticker
- mode: test (TEST: not user-approved)

## Sources
- SRC1: Chromium Blog: An Update on the Lock Icon <https://blog.chromium.org/2023/05/an-update-on-lock-icon.html> (primary, 2026-11-16T22:00:00Z)
- SRC2: Chromium Blog: Increasing HTTPS adoption <https://blog.chromium.org/2021/07/increasing-https-adoption.html> (primary, 2026-11-16T22:00:00Z)
- SRC3: BleepingComputer: Google will remove secure website indicators in Chrome 117 <https://www.bleepingcomputer.com/news/google/google-will-remove-secure-website-indicators-in-chrome-117/> (secondary, 2026-11-16T22:00:00Z)

## Approvals


## Critics
| critic | verdict | score | blockers+majors | how |
|---|---|---|---|---|
| research | pass | 100 | 0 | automatic |
| script | pass | 100 | 0 | automatic |
| storyboard | pass | 100 | 0 | automatic |
| captions | pass | 94 | 0 | automatic |
| voice | pass | 98 | 0 | automatic |
| music | pass | 100 | 0 | automatic |
| sfx | pass | 100 | 0 | automatic |
| frames | pass | 100 | 0 | automatic |
| video | pass | 100 | 0 | automatic |
| final | pass | 100 | 0 | automatic |

Automatic critics measure; they do not hear or judge taste. Vision critics run only when the agent opened the images.
