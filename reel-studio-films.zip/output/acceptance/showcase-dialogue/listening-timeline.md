# Listening transcript (measured, not heard)

length 23.01 s, mean level -25 dBFS, peak -8.6 dBFS, speech 69 percent of the time, 16 sound cues, music 17.3 dB under the voice

## Flags
- @17 s **level jump**: -29 to -16 dBFS between seconds 16 and 17
- @18 s **level jump**: -16 to -26 dBFS between seconds 17 and 18
- @13.02 s **cue barely audible**: heartbeat at 13.02 s adds only -0.9 dB over what plays under it: it may be masked by the voice or music
- @15.18 s **cue barely audible**: pop at 15.18 s adds only -2.7 dB over what plays under it: it may be masked by the voice or music

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -21 | voice | S01 | pop@0.44 |
| 1 | -20 | voice | S01 | tick@1.86 |
| 2 | -27 | voice | S01 | whoosh@2.73 |
| 3 | -19 | voice | S02 | stamp@3.14, pop@3.96 |
| 4 | -21 | voice | S02 |  |
| 5 | -27 | voice | S02 |  |
| 6 | -21 | voice | S03 | boom@6.46 |
| 7 | -23 | voice | S04 | count@7.62 |
| 8 | -24 | voice | S04 |  |
| 9 | -27 | voice | S04 |  |
| 10 | -26 | voice | S04 | pop@10.26 |
| 11 | -23 | voice | S05 | whoosh@11.25, pop@11.86 |
| 12 | -22 | voice | S05 |  |
| 13 | -26 | voice | S05 | heartbeat@13.02 |
| 14 | -22 | voice | S06 |  |
| 15 | -25 | voice | S06 | pop@15.18 |
| 16 | -29 | voice | S06 |  |
| 17 | -16 | voice | S07 | tick@17.18, tick@17.74 |
| 18 | -26 | voice | S07 |  |
| 19 | -23 | voice | S08 |  |
| 20 | -25 | voice | S08 | type@20.84 |
| 21 | -31 | - | S08 |  |
| 22 | -39 | - | S08 | ding@22.31 |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
