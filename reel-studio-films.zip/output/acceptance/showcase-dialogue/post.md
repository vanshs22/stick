# Post draft

## Caption
The padlock is on, so this site is safe, right?

- Wrong. Nearly all phishing sites show that padlock too.
- Wait, what?
- Only eleven percent understand the lock. Chrome replaced it.
- So my password was about to go to a fake site?
- The lock only means the connection is encrypted.

Save this before a padlock fools you. Comment LOCK.

#browser #padlock #mean #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: a login page with a padlock in the address bar: what Leo trusts
- S02: a WRONG stamp slams over the idea that the padlock means safe
- S03: Leo is shocked: a two-word jolt
- S04: 11 percent counts up: how few people understand the lock
- S05: the real bank and the fake bank look identical: both have the padlock
- S06: the real Chromium blog post that explains what the lock means
- S07: two habits tick in: read the address, ignore the icon
- S08: the comment box asks for the keyword LOCK

## Cover
renders/cover.jpg (frame at 2.01 s)
