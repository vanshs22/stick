# Production report: The golden key

- video: experiment-stick.mp4, 11.9 s, 1080x1920
- style: stickman-3d
- mode: test (TEST: not user-approved)

## Sources
(none)

## Approvals


## Critics
| critic | verdict | score | blockers+majors | how |
|---|---|---|---|---|
| research | pass | 100 | 0 | automatic |
| script | pass | 100 | 0 | automatic |
| storyboard | pass | 98 | 0 | automatic |
| captions | pass | 100 | 0 | automatic |
| voice | pass | 100 | 0 | automatic |
| music | pass | 100 | 0 | automatic |
| sfx | pass | 100 | 0 | automatic |
| frames | pass | 100 | 0 | automatic |
| video | pass | 98 | 0 | automatic |
| final | pass | 100 | 0 | automatic |

Automatic critics measure; they do not hear or judge taste. Vision critics run only when the agent opened the images.
