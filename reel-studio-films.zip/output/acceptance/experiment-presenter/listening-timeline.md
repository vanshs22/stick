# Listening transcript (measured, not heard)

length 12.50 s, mean level -22 dBFS, peak -10.6 dBFS, speech 78 percent of the time, 3 sound cues, music 19.5 dB under the voice

## Flags
- @7.568 s **cue barely audible**: pop at 7.57 s adds only -9.8 dB over what plays under it: it may be masked by the voice or music

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -22 | voice | S01 | pop@0.20 |
| 1 | -19 | voice | S01 |  |
| 2 | -20 | voice | S01 |  |
| 3 | -21 | voice | S02 |  |
| 4 | -23 | voice | S02 |  |
| 5 | -18 | voice | S02 |  |
| 6 | -22 | voice | S03 |  |
| 7 | -21 | voice | S03 | pop@7.57 |
| 8 | -19 | voice | S04 | sparkle@8.07 |
| 9 | -21 | voice | S04 |  |
| 10 | -22 | voice | S05 |  |
| 11 | -31 | - | S05 |  |
| 12 | -43 | - | - |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
