# Post draft

## Caption
Last night, a mysterious box showed up at my door.

- I picked it up, and I had no idea who sent it.
- So I opened it.
- And inside was a tiny golden key.
- No way.

Comment KEY.

#mysterious #golden #style #experiment #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: establish the room, the table and the box
- S02: hero tells it to camera
- S03: hero opens the box
- S04: the key rises out of the box
- S05: hero reacts

## Cover
renders/cover.jpg (frame at 2.34 s)
