# Post draft

## Caption
What if making a video was as simple as writing a web page?

- Remotion gives you a frame number and a blank canvas.
- Over seventy thousand people have starred it on GitHub.

Comment REMOTION and I will send you the docs link.

#remotion #making #videos #react #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: the duo on the stage with a set piece
- S02: the real page "The core idea | Remotion" on a floating screen
- S03: the real page "GitHub - remotion-dev/remotion: 🎥 Make videos pro" on a floating screen
- S04: both characters ask for the comment

## Cover
renders/cover.jpg (frame at 1.6 s)
