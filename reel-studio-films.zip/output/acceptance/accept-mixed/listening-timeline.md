# Listening transcript (measured, not heard)

length 14.27 s, mean level -23 dBFS, peak -11.3 dBFS, speech 76 percent of the time, 1 sound cues, music 18.9 dB under the voice

## Flags
- none

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -21 | voice | S01 |  |
| 1 | -21 | voice | S01 |  |
| 2 | -18 | voice | S01 |  |
| 3 | -25 | voice | S01 |  |
| 4 | -19 | voice | S02 |  |
| 5 | -22 | voice | S02 |  |
| 6 | -24 | voice | S02 |  |
| 7 | -16 | voice | S03 |  |
| 8 | -23 | voice | S03 |  |
| 9 | -23 | voice | S03 |  |
| 10 | -19 | voice | S04 | zap@10.34 |
| 11 | -19 | voice | S04 |  |
| 12 | -26 | voice | S04 |  |
| 13 | -35 | - | S04 |  |
| 14 | -48 | - | - |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
