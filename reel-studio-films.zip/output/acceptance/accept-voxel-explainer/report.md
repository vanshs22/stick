# Production report: An API is a waiter

- video: accept-voxel-explainer.mp4, 12.8 s, 1080x1920
- style: voxel-explainer
- mode: test (TEST: not user-approved)

## Sources
- SRC1: MDN glossary: API <https://developer.mozilla.org/en-US/docs/Glossary/API> (primary, 2026-11-16T22:00:00Z)
- SRC2: Red Hat: What is an API? <https://www.redhat.com/en/topics/api/what-are-application-programming-interfaces> (official, 2026-11-16T22:00:00Z)

## Approvals


## Critics
| critic | verdict | score | blockers+majors | how |
|---|---|---|---|---|
| research | pass | 100 | 0 | automatic |
| script | pass | 100 | 0 | automatic |
| storyboard | pass | 98 | 0 | automatic |
| captions | pass | 100 | 0 | automatic |
| voice | pass | 100 | 0 | automatic |
| music | pass | 100 | 0 | automatic |
| sfx | pass | 100 | 0 | automatic |
| frames | pass | 100 | 0 | automatic |
| video | revise | 88 | 1 | automatic |
| final | pass | 100 | 0 | automatic |

Automatic critics measure; they do not hear or judge taste. Vision critics run only when the agent opened the images.
