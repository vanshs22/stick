# Post draft

## Caption
What does an API actually do?

- It is a waiter between you and the kitchen.
- You send an order, and the waiter carries it.
- Then the answer comes back on a plate.

Save this to remember it.

#waiter #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: the voxel person looks at a laptop and a closed box: two things that need to talk
- S02: a second voxel person plays the waiter between the guest and the kitchen box
- S03: the guest types an order and the waiter walks toward the kitchen
- S04: the gift box opens like a covered plate: the answer arrives
- S05: the voxel person waves with a plaque

## Cover
renders/cover.jpg (frame at 2.29 s)
