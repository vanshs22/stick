# Listening transcript (measured, not heard)

length 12.89 s, mean level -23 dBFS, peak -13.0 dBFS, speech 77 percent of the time, 5 sound cues, music 19.7 dB under the voice

## Flags
- @11 s **level jump**: -18 to -28 dBFS between seconds 10 and 11

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -22 | voice | S01 |  |
| 1 | -21 | voice | S01 | pop@1.28 |
| 2 | -22 | voice | S02 | ding@2.96 |
| 3 | -20 | voice | S02 |  |
| 4 | -26 | voice | S02 |  |
| 5 | -19 | voice | S03 | tick@5.58 |
| 6 | -22 | voice | S03 |  |
| 7 | -23 | voice | S03 |  |
| 8 | -20 | voice | S04 |  |
| 9 | -25 | voice | S04 | sparkle@9.30 |
| 10 | -18 | voice | S05 | pop@10.00 |
| 11 | -28 | voice | S05 |  |
| 12 | -41 | - | S05 |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
