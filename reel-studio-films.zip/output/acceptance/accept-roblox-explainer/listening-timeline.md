# Listening transcript (measured, not heard)

length 13.92 s, mean level -21 dBFS, peak -10.6 dBFS, speech 73 percent of the time, 5 sound cues, music 19.3 dB under the voice

## Flags
- @12 s **level jump**: -17 to -27 dBFS between seconds 11 and 12

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -19 | voice | S01 |  |
| 1 | -18 | voice | S01 | pop@1.46 |
| 2 | -21 | voice | S01 |  |
| 3 | -20 | voice | S02 | sparkle@3.92 |
| 4 | -19 | voice | S02 |  |
| 5 | -18 | voice | S03 |  |
| 6 | -20 | voice | S03 | tick@6.92 |
| 7 | -21 | voice | S03 |  |
| 8 | -17 | voice | S04 |  |
| 9 | -19 | voice | S04 | ding@9.64 |
| 10 | -23 | voice | S04 |  |
| 11 | -17 | voice | S05 | pop@11.50 |
| 12 | -27 | - | S05 |  |
| 13 | -39 | - | S05 |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
