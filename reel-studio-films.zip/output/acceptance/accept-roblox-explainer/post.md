# Post draft

## Caption
Why does a website load instantly the second time?

- Because a cache saves the answer.
- The first visit is slow. It fetches everything.
- The next visit just reads the saved copy.

Save this, and comment CACHE.

#cache #second #visit #fast #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: the avatar waits on the spawn pad next to a laptop that is still loading
- S02: the avatar explains; a trophy on a podium stands for the saved answer
- S03: close on the laptop typing a slow fetch while a counter climbs to 800 ms
- S04: same laptop, instant: the counter drops to 40 ms and the avatar points at the saved copy
- S05: the avatar waves and the plaque names the comment keyword

## Cover
renders/cover.jpg (frame at 1.74 s)
