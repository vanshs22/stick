# Listening transcript (measured, not heard)

length 16.79 s, mean level -25 dBFS, peak -11.5 dBFS, speech 77 percent of the time, 8 sound cues, music 18.0 dB under the voice

## Flags
- @4 s **level jump**: -28 to -19 dBFS between seconds 3 and 4
- @15 s **level jump**: -21 to -34 dBFS between seconds 14 and 15
- @10.784 s **cue barely audible**: swish at 10.78 s adds only -0.1 dB over what plays under it: it may be masked by the voice or music

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -24 | voice | S01 |  |
| 1 | -21 | voice | S01 |  |
| 2 | -22 | voice | S01 | pop@2.28 |
| 3 | -28 | voice | S01 | swish@3.90 |
| 4 | -19 | voice | S02 | tick@4.14 |
| 5 | -25 | voice | S02 | ding@5.48 |
| 6 | -25 | voice | S02 |  |
| 7 | -23 | voice | S03 |  |
| 8 | -24 | voice | S03 | type@8.40 |
| 9 | -23 | voice | S03 |  |
| 10 | -27 | voice | S03 | swish@10.78 |
| 11 | -20 | voice | S04 | pop@11.04 |
| 12 | -22 | voice | S04 |  |
| 13 | -25 | voice | S05 | ding@13.82 |
| 14 | -21 | voice | S05 |  |
| 15 | -34 | - | S05 |  |
| 16 | -42 | - | S05 |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
