# Listening transcript (measured, not heard)

length 36.08 s, mean level -19 dBFS, peak -9.1 dBFS, speech 79 percent of the time, 23 sound cues, music 14.0 dB under the voice

## Flags
- @3 s **level jump**: -26 to -13 dBFS between seconds 2 and 3
- @24 s **level jump**: -24 to -14 dBFS between seconds 23 and 24
- @35 s **level jump**: -26 to -35 dBFS between seconds 34 and 35

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -23 | voice | S01 | pop@0.30 |
| 1 | -18 | voice | S01 | tick@1.42 |
| 2 | -26 | - | S01 | whoosh@2.95 |
| 3 | -13 | voice | S02 | count@3.14, pop@3.22 |
| 4 | -15 | voice | S02 |  |
| 5 | -19 | voice | S02 |  |
| 6 | -20 | voice | S03 | pop@6.36 |
| 7 | -17 | voice | S03 |  |
| 8 | -18 | voice | S03 | ding@8.52 |
| 9 | -21 | voice | S03 |  |
| 10 | -17 | voice | S04 | swish@10.19, type@10.36 |
| 11 | -16 | voice | S04 |  |
| 12 | -17 | voice | S04 | type@12.90 |
| 13 | -21 | voice | S04 |  |
| 14 | -18 | voice | S05 |  |
| 15 | -19 | voice | S05 |  |
| 16 | -19 | voice | S05 | tick@16.36, tick@16.96 |
| 17 | -19 | voice | S05 | tick@17.52 |
| 18 | -23 | voice | S06 | pop@18.58 |
| 19 | -17 | voice | S06 |  |
| 20 | -19 | voice | S06 | blip@20.28 |
| 21 | -16 | voice | S06 |  |
| 22 | -23 | voice | S06 | pop@22.32 |
| 23 | -24 | - | S06 | whoosh@23.63, pop@23.80, boom@23.98 |
| 24 | -14 | voice | S07 |  |
| 25 | -16 | voice | S07 |  |
| 26 | -15 | voice | S07 |  |
| 27 | -23 | voice | S07 | pop@27.85 |
| 28 | -17 | voice | S08 | stamp@28.12 |
| 29 | -19 | voice | S08 |  |
| 30 | -19 | voice | S08 |  |
| 31 | -25 | voice | S08 |  |
| 32 | -18 | voice | S09 | type@32.32 |
| 33 | -18 | voice | S09 | ding@33.17 |
| 34 | -26 | - | S09 |  |
| 35 | -35 | - | S09 |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
