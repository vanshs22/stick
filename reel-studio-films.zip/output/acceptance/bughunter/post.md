# Post draft

## Caption
What if Claude thought like a senior bug hunter?

- One free repo gives Claude Code over eighty hunting skills.
- It is called Claude BugHunter, with over eight thousand stars.
- Install it once, then describe your target in plain English.
- The right skill loads by itself: recon, hunting, or reporting.
- Fifteen slash commands, and six hundred eighty-one real report patterns.

Comment HUNT, and start thinking like a bug hunter.

#claude #bughunter #free #code #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: the question over a real server rack: Claude, thinking like a bug hunter
- S02: 80+ hunting skills counts up
- S03: the repo’s own star history, circled
- S04: the two install commands, then a plain-English request, typed in a terminal
- S05: recon, hunt and report tick off as the right skill loads
- S06: 15 commands, 681 patterns, 24 classes pop in one by one
- S07: the README paragraph that names the 7-Question Gate, circled
- S08: SECURITY.md: assets you own or have written authorization to assess
- S09: the comment box asks for HUNT

## Cover
renders/cover.jpg (frame at 1.49 s)
