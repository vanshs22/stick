# Listening transcript (measured, not heard)

length 18.34 s, mean level -26 dBFS, peak -9.5 dBFS, speech 66 percent of the time, 12 sound cues, music 17.3 dB under the voice

## Flags
- @12.96 s **cue barely audible**: pop at 12.96 s adds only -5.5 dB over what plays under it: it may be masked by the voice or music
- @17.535 s **cue barely audible**: ding at 17.54 s adds only +0.2 dB over what plays under it: it may be masked by the voice or music

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -22 | voice | S01 | pop@0.30 |
| 1 | -21 | voice | S01 | tick@1.80 |
| 2 | -23 | voice | S01 |  |
| 3 | -25 | - | S02 | whoosh@3.32, stamp@3.74 |
| 4 | -22 | voice | S02 | pop@4.10 |
| 5 | -23 | voice | S02 |  |
| 6 | -31 | - | S02 | boom@6.90 |
| 7 | -22 | voice | S03 | pop@7.91 |
| 8 | -24 | voice | S04 |  |
| 9 | -27 | voice | S04 |  |
| 10 | -21 | voice | S05 | whoosh@10.11, heartbeat@10.62 |
| 11 | -29 | voice | S05 |  |
| 12 | -24 | voice | S05 | pop@12.96 |
| 13 | -30 | voice | S05 |  |
| 14 | -23 | voice | S06 |  |
| 15 | -28 | voice | S06 |  |
| 16 | -28 | voice | S06 | type@16.12 |
| 17 | -36 | - | S06 | ding@17.54 |
| 18 | -49 | - | - |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
