# Post draft

## Caption
Incognito mode makes me invisible online, right?

- Wrong. Your boss, school and Wi-Fi may still see.
- Wait, what?!
- It only hides history from your browser.
- So my boss saw everything?!
- Maybe. Close that tab.

Save this before incognito fools you. Comment HIDE.

#incognito #mode #hide #invisible #shorts

(Draft: the hashtags are guessed from the title, so replace them (or run again with --tags a,b,c) and edit the wording. The voice is AI-generated: switch on the platform's AI label.)

## Alt text (one line per shot; put a clean description in the shot field alt)
- S01: two friends at a laptop: Dan states his belief
- S02: Zoe corrects him: close-up with the three who can still see
- S03: Dan is shocked: extreme close-up, giant WHAT?!
- S04: the real Chrome Help page, scrolled to who can still observe your activity
- S05: Dan realises, Zoe answers dry: a slow pull-out like the reference
- S06: the comment box asks for HIDE, over a blurred real city night

## Cover
renders/cover.jpg (frame at 4.4 s)
