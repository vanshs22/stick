# 1-minute listening checklist

Play each clip once. Tick or write one word. Only a person can judge these.

1. `listen/01-hook.mp3` (0.0-3.5 s): Is the first sentence clear and pleasant, and is the music out of its way?  [ ] good  [ ] fix: ________
2. `listen/02-cue-S01-pop.mp3` (0.0-3.2 s): The pop is meant to land on: shot start: on-screen event: establish the room, the table and the box. Does it land on that moment and feel right, not random?  [ ] good  [ ] fix: ________
3. `listen/03-cue-S03-pop.mp3` (5.9-9.1 s): The pop is meant to land on: shot start: on-screen event: hero opens the box. Does it land on that moment and feel right, not random?  [ ] good  [ ] fix: ________
4. `listen/04-cue-S04-sparkle.mp3` (6.4-9.6 s): The sparkle is meant to land on: shot start: on-screen event: the key rises out of the box. Does it land on that moment and feel right, not random?  [ ] good  [ ] fix: ________
5. `listen/05-loudest.mp3` (3.5-6.5 s): The loudest second: is anything harsh or fatiguing?  [ ] good  [ ] fix: ________
6. `listen/06-ending.mp3` (8.5-12.0 s): The ending: does it close cleanly (no cut-off word, no abrupt music stop)?  [ ] good  [ ] fix: ________

Also decide: voice (keep / change voice or speed), music (keep / quieter / none), effects (keep / fewer). Tell the agent in one line each: `tools/choose.mjs <P> voice ...`.
