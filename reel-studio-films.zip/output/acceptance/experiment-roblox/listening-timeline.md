# Listening transcript (measured, not heard)

length 11.96 s, mean level -21 dBFS, peak -11.1 dBFS, speech 75 percent of the time, 3 sound cues, music 20.2 dB under the voice

## Flags
- @7.124 s **cue barely audible**: pop at 7.12 s adds only -9.1 dB over what plays under it: it may be masked by the voice or music

## Per second
| t (s) | level dBFS | speech | shot | sound cues |
|---|---|---|---|---|
| 0 | -20 | voice | S01 | pop@0.20 |
| 1 | -18 | voice | S01 |  |
| 2 | -18 | voice | S01 |  |
| 3 | -20 | voice | S02 |  |
| 4 | -17 | voice | S02 |  |
| 5 | -21 | voice | S02 |  |
| 6 | -17 | voice | S03 |  |
| 7 | -19 | voice | S04 | pop@7.12, sparkle@7.58 |
| 8 | -17 | voice | S04 |  |
| 9 | -21 | voice | S04 |  |
| 10 | -27 | - | S05 |  |
| 11 | -37 | - | S05 |  |

> This measures levels, gaps, sync and masking. It cannot judge taste: see listen/CHECKLIST.md for the moments a person should play.
