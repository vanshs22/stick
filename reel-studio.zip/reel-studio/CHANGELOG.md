# Changelog

## Production toolkit pass
- **Voice casting and emotion:** `script.cast`, per-line `speaker`, `emotion` (13) and `tts_text`; gender-matched, unique voices; refusals tested (`selftest_voice.mjs`).
- **4K export:** `tools/upscale.mjs` and `build_video.mjs --upscale` (Lanczos, instant, made from the file that passed QA).
- **Reference style with a twist:** `tools/reference/twist.mjs` + `tools/lib/twist.mjs`; the `reference` critic checks each lever (`selftest_twist.mjs`).
- **Toolchain critic:** proves from evidence files that each stage's tool ran (research, critics, cues, mix report, casting, ears, contact sheet, 4K, twist).
- **Craft playbook:** `skills/reel-craft/SKILL.md` (hooks, pacing, overlay and mockup placement table, sound by event, voice, twist, speed).
- **Presenter:** per-shot `presenter.look` (two characters on one rig, `longHair`), speaker tag on headline captions, headline captions limited to one line.
- **Approvals:** signed chain (hand-edited `state.json` is detected), accurate "already approved" message, `request intake` validates `brief.json`, `seal` prints usage.
- **Fixes found by rendering and by CI:** caption safe-zone check used the content limit (1380) instead of the caption limit (1500); captions under 0.2 s are merged; critics ignore `*.4k.mp4`; capture retries on HTTP 429/5xx; installer repairs a venv without pip, honours `REEL_HOME` everywhere, prefers Python 3.10 to 3.13; Windows `import()` needs file URLs; `doctor --allow-missing-models` for the clean-room test.
- **Content:** research files for all acceptance films, visual concepts for the story films, `examples/showcase-dialogue`, style previews and samples for every pack, `scripts/pack.mjs` to build the zip.
