# Changelog

## Reference style (image or video)
- `skills/reference-style`, `tools/reference/style_brief.mjs` + `style_measure.py`, `style_map.mjs`, `style_check.mjs`, `tools/critics/style.mjs`, style levers in the twist, `style` in the toolchain and `next.mjs`, a worked example brief, `selftest_style.mjs`. `preview_shots` rebuilds a stale timeline; opencv pinned `<5`.

## Final pass: viral script editor, reference remake, assets
- `START-HERE.md` (the flow and ten quality rules), `skills/viral-script`, `tools/script_studio.mjs` + `critics/viral.mjs`, `viral-plan` schema; `next.mjs` leads with the plan.
- `tools/reference/blueprint.mjs`; `next.mjs` now covers the reference flow (ingest, blueprint, twist).
- `tools/assets/fetch.mjs` (CC0 photos and music with provenance, measured size, contact sheet), `shot.bgImage`, `style-overrides.json`.
- Renderer: speaker-driven mouths in 3D dialogue, `presenter.look.longHair`, SVG ticks, `CommentBox.typeAnchor`, one-line headline captions, light/dark scrim.
- Tools: `finalVideo()` (never a stale preview), signed approvals, faster Lanczos export, `selftest` parses every tool script.

## Production toolkit pass
- **Voice casting and emotion:** `script.cast`, per-line `speaker`, `emotion` (13) and `tts_text`; gender-matched, unique voices; refusals tested (`selftest_voice.mjs`).
- **4K export:** `tools/upscale.mjs` and `build_video.mjs --upscale` (Lanczos, instant, made from the file that passed QA).
- **Reference style with a twist:** `tools/reference/twist.mjs` + `tools/lib/twist.mjs`; the `reference` critic checks each lever (`selftest_twist.mjs`).
- **Toolchain critic:** proves from evidence files that each stage's tool ran (research, critics, cues, mix report, casting, ears, contact sheet, 4K, twist).
- **Craft playbook:** `skills/reel-craft/SKILL.md` (hooks, pacing, overlay and mockup placement table, sound by event, voice, twist, speed).
- **Presenter:** per-shot `presenter.look` (two characters on one rig, `longHair`), speaker tag on headline captions, headline captions limited to one line.
- **Approvals:** signed chain (hand-edited `state.json` is detected), accurate "already approved" message, `request intake` validates `brief.json`, `seal` prints usage.
- **Fixes found by rendering and by CI:** caption safe-zone check used the content limit (1380) instead of the caption limit (1500); captions under 0.2 s are merged; critics ignore `*.4k.mp4`; capture retries on HTTP 429/5xx; installer repairs a venv without pip, honours `REEL_HOME` everywhere, prefers Python 3.10 to 3.13; Windows `import()` needs file URLs; `doctor --allow-missing-models` for the clean-room test.
- **Content:** research files for all acceptance films, visual concepts for the story films, `examples/showcase-dialogue`, style previews and samples for every pack, `scripts/pack.mjs` to build the zip.
