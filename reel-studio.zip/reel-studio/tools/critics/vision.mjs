// Vision critics: character, environment, camera, composition, typography, ui, transitions, frames, video, reference.
// These need EYES. The tool builds a packet (images to open + a rubric), validates the agent's findings and refuses to claim it looked when it did not.
//   critique.mjs <P> vision --packet <critic>                       -> review/critics/vision/<critic>/packet.md + findings.template.json
//   critique.mjs <P> vision --submit <critic> --file findings.json  -> review/critics/<critic>.json (assessment: vision)
//   critique.mjs <P> vision --unavailable <critic> "why"            -> report says the checks were NOT performed (verdict revise)
import fs from 'node:fs';
import path from 'node:path';
import { Report, tryRd } from './lib.mjs';
import { TK, run } from '../lib/pipeline.mjs';
const RUBRIC = {
  character: ['same character, same look, same proportions in every shot', 'face reads at phone size: eyes, brows, mouth show the emotion the line needs', 'hands/arms/legs look attached and natural, no floating or crossing geometry', 'pose and gesture match what is said', 'silhouette is clear against the background', 'matches the style pack character rules'],
  environment: ['depth: foreground, action plane, background are distinct', 'props support the story, nothing random', 'lighting direction and mood are consistent across shots of one location', 'no empty dead areas, no clutter hiding the subject', 'the world looks designed, not assembled from primitives'],
  camera: ['framing matches the emotional need (wide = context, close = feeling)', 'every move has a visible reason and ends where it promised', 'screen direction and eyelines are consistent across cuts', 'no accidental dutch tilt, no jarring jump cuts'],
  composition: ['subject placement (thirds / centre) is deliberate', 'headroom and look-room are comfortable', 'nothing important is covered by captions, overlays or platform buttons', 'foreground/background separation (focus, light, colour)'],
  typography: ['hierarchy: one thing is read first', 'size and weight readable on a phone at arm length', 'contrast against the picture behind it, outline where needed', 'no overlaps between text, overlays and captions', 'font pairing and case are consistent with the style'],
  ui: ['cards/windows are fully visible and legible, not cut off', 'real evidence (screenshots) is sharp and the highlighted part is visible', 'animation in/out is clean (no pops, no overshoot clipping)', 'colours match the style pack'],
  transitions: ['each transition has a reason (time jump, location change, match)', 'the motion and the sound agree', 'no flash frames or half-finished states'],
  frames: ['no artifacts: z-fighting, shadow acne, clipping through walls, floating props', 'no uncanny or broken faces', 'no stretched or blurry textures', 'exposure is comfortable, nothing blown or crushed by accident'],
  video: ['the edit tells the story from the first frame; no confusing beat', 'pace follows the emotion: holds where the performance carries, cuts where information changes', 'the ending lands (payoff + CTA)', 'the whole film feels like ONE design'],
  reference: ['same production language as the reference (pace, framing, text placement) without copying its characters, shots or wording', 'there is an original twist that makes it ours'],
};
export async function run_(P, a) {
  const kind = a.includes('--packet') ? 'packet' : a.includes('--submit') ? 'submit' : a.includes('--unavailable') ? 'unavailable' : null, name = a[a.indexOf('--' + kind) + 1];
  if (!kind || !RUBRIC[name]) { console.error(`usage: vision --packet|--submit|--unavailable <${Object.keys(RUBRIC).join('|')}>`); process.exit(2); }
  const dir = path.join(P, 'review/critics/vision', name); fs.mkdirSync(dir, { recursive: true });
  const imgs = () => { const out = []; const sb = path.join(P, 'review/storyboard'); if (fs.existsSync(sb)) fs.readdirSync(sb).filter((f) => /^S\d+\.png$/.test(f)).sort().forEach((f) => out.push(`review/storyboard/${f}`)); for (const f of ['review/storyboard-sheets/storyboard-1.jpg', 'review/final.jpg', 'review/video.jpg', 'review/render-analysis/contact_sheet.jpg']) if (fs.existsSync(path.join(P, f))) out.push(f); return out; };
  if (kind === 'packet') {
    const list = imgs(); if (!list.length) { console.error('no images yet: render stills (tools/preview_shots.mjs) or the film first'); process.exit(1); }
    fs.writeFileSync(path.join(dir, 'packet.json'), JSON.stringify({ critic: name, images: list, rubric: RUBRIC[name], created: new Date().toISOString() }, null, 1));
    fs.writeFileSync(path.join(dir, 'findings.template.json'), JSON.stringify({ inspected: [], rubric_answers: RUBRIC[name].map((q) => ({ question: q, answer: '', ok: null })), findings: [{ severity: 'minor', shot_id: 'S01', timestamp_sec: 0, problem: '', evidence: 'what you SAW, in a few words', expected: '', fix: '', fix_target: 'storyboard' }] }, null, 1));
    fs.writeFileSync(path.join(dir, 'packet.md'), `# ${name} critic (needs eyes)\n\nOpen these images (list each one you opened in "inspected"):\n${list.map((i) => `- ${i}`).join('\n')}\n\nRubric:\n${RUBRIC[name].map((q) => `- ${q}`).join('\n')}\n\nFill findings.template.json, then: node tools/critique.mjs ${P} vision --submit ${name} --file ${path.join(dir, 'findings.template.json')}\nIf your model cannot see images: node tools/critique.mjs ${P} vision --unavailable ${name} "reason"\n`);
    console.log(`packet ready: ${path.relative(P, dir)}/packet.md (${list.length} image(s))`); return;
  }
  const r = new Report(P, name, kind === 'submit' ? 'vision' : 'unavailable');
  if (kind === 'unavailable') { const why = a[a.indexOf('--unavailable') + 2] || 'no image input'; r.add('major', { problem: `the ${name} critic did NOT run: ${why}`, evidence: 'no image was inspected', expected: 'a model that can see images, or the user looking at the contact sheet', fix: 'ask the user to review these checks by eye: ' + RUBRIC[name].join(' | '), fix_target: 'style' }); r.notes.push('Not assessed: ' + RUBRIC[name].join('; ')); return r.finish(); }
  const f = tryRd(path.resolve(a[a.indexOf('--file') + 1])), pk = tryRd(path.join(dir, 'packet.json')); if (!f || !pk) { console.error('need --file findings.json and a packet (run --packet first)'); process.exit(1); }
  const errs = []; if (!f.inspected?.length) errs.push('inspected[] is empty: a vision critic must list the images it opened'); for (const i of f.inspected || []) if (!pk.images.includes(i)) errs.push(`"${i}" is not in the packet`); if ((f.inspected || []).length < Math.min(3, pk.images.length)) errs.push('open at least 3 images (or all, if fewer)'); if ((f.rubric_answers || []).some((x) => !x.answer)) errs.push('every rubric question needs an answer'); for (const x of f.findings || []) if (x.problem && !x.evidence) errs.push('every finding needs evidence of what you saw');
  if (errs.length) { console.error('findings rejected:\n- ' + errs.join('\n- ')); process.exit(1); }
  r.check(...[]); RUBRIC[name].forEach((q) => r.check(q)); for (const x of (f.findings || []).filter((x) => x.problem)) r.add(x.severity || 'minor', { shot_id: x.shot_id, timestamp_sec: x.timestamp_sec, problem: x.problem, evidence: x.evidence, expected: x.expected || '', fix: x.fix || '', fix_target: x.fix_target || 'storyboard' }); r.notes.push(`inspected: ${f.inspected.join(', ')}`); return r.finish();
}
