# Status: what is implemented, tested, and still open

"Tested" means a command was run and its output read. Nothing here is claimed from files alone. Updated after the production-toolkit pass (voice casting, 4K, twist, toolchain critic, 3D films, CI).

## Verified by running
- **Self-tests:** `node tools/selftest.mjs` (fast) and `--full`; pipeline gates `tools/selftest_pipeline.mjs` (57 checks); approval workflow `tools/selftest_state.mjs`; voice casting and emotion `tools/selftest_voice.mjs --full`; twist engine `tools/selftest_twist.mjs`.
- **Clean-room install on GitHub Actions** (`.github/workflows/clean-install.yml` in the repo that holds the zip): **Ubuntu, macOS and Windows all pass** install, doctor, self-tests and a real render (GitHub Actions, run on the final zip). The voice model download (340 MB) is skipped there; the voice is tested on Linux (`selftest_voice.mjs --full`).
- **All eight 3D / acceptance films rendered at 1080x1920 with real Kokoro voice, QA passing:** Roblox, voxel, mixed, and the Roblox / stickman / presenter story trio (about 15 to 18 minutes each on 8 CPU cores, software GL), plus the earlier software-demo and motion-explainer. Contact sheet of the 3D films was looked at. Films and critic reports: `reel-studio-films.zip` (`output/acceptance/` inside).
- **Research critic** passes on every acceptance film: each ships `research.json` with real, reachable sources; invented numbers are labelled `opinion`.
- **Per-style previews:** all 11 style packs have `preview/motion.mp4` (3 s) and `preview/sample.mp4` (a whole film, 540x960 with sound) made from real renders (`tools/style_samples.mjs`). The samples for noir-3d, original-creatures, paper-atlas and voxel-studio are half-size renders of the shared example scripts in that style.
- **Showcase film `examples/showcase-dialogue` (22.9 s, rebuilt after the tick fix):** two characters (Leo male, Maya female) with seven different emotions, a real captured Chromium blog page as proof, mockups tied to words, events-tied sound. 8 shots rendered in about 1 minute; Lanczos 4K file 2160x3840 decodes cleanly; all 14 critic checks pass. Found and fixed by looking at its contact sheet (see CHANGELOG).
- **A fresh low-context agent test** (reads only AGENTS.md, tries to skip gates): approvals without `request`, delegated final, seal before approval and build before approval were refused. It found that a hand-edited `state.json` was trusted: fixed (signed approval chain), plus a misleading message and a missing `seal` usage line. The sub-agent runs on whatever model the host uses; I could not force a cheap model, so this proves the instructions and gates, not a specific model.

## Gates, voice and quality guards (latest pass)
- **Gates:** 5 (was 14). `selftest_state.mjs` 100 percent, `selftest_pipeline.mjs` 56 checks.
- **Voice:** directed delivery raises measured aliveness 0.60 to 0.92-0.94; earshot realness 0.775 to 0.81 after polish, 0.88 on the finished film. Still a synthetic voice (own recording is best). Orpheus/Chatterbox not shipped (GPU, untested).
- **Guards:** a blurred film, a film without audible music and a film without enough sound effects now FAIL final QA.
- **Claude-BugHunter film** (`examples/showcase-bughunter`, 36 s, 1080x1920, 4K via `--upscale`): QA 22 checks pass, 15 critics pass, loudness -14.0 LUFS. Open earshot notes: thin bottom end; salient-hit density (not fixable on narrated explainers, see audio-production).
- **Open:** TEST-project films have no human approvals; the 3D films were not re-rendered in this pass.

## Inkbeat style (storyboard stage)
- Renderer vendored and run: the starter's demo stills and our 9-shot BugHunter storyboard (27 stills, 540x960) render with ink outlines, painted textures and moods. Plan tool reports 62 camera events a minute (target 56 +- 4, planned ~10 percent over), 9/9 sentence starts on a beat. Found by looking: a gate post hiding its sign, a subject leaving the frame during a drift, a floating tag; fixed.
- **Not done:** no full video render yet (software GL: about 15 s a still, hours for 35 s), no audio mux, not wired into `build_video`/gates, `analyze_pacing.py` not yet run on a render, push-through is a lens punch (no motion blur on the cut).

## Common camera grammar and the four new styles
- **Done and looked at:** one look-dev sheet (12 stills, `examples/styles-lookdev/looks.jpg`): kidsong (16:9), zackd (9:16), anime (16:9), pixar (16:9). Found by looking and fixed: milky washes in three looks, a cutaway shown from its closed side, anime petals as black dots and a wire like a beam, an orange-on-orange kitchen. 16:9 long-form checked on a Story frame (1920x1080).
- **Not done:** no full story or video in any of the four styles yet, no character animation on twos or impact frames implemented (documented in the anime pack, needs a Story option), the zackd cutaway is a clean ring section, not a modelled organ; characters share one family so faces differ by build, eyes, hair and outfit only. Other packs (2D, Stage3D) are still vertical only; only the inkbeat engine renders 16:9.

## Portrait and landscape
- **A full film built in 16:9 end to end** (`acceptance.mjs showcase-bughunter --aspect 16:9`): re-captured pages at a landscape viewport, circles synced to the new captures, voice, music and sound, 1920x1080 render, QA all ok, 4K (3840x2160) upscale, critics pass (toolchain only asked for the 4K file). Contact sheet looked at: wide cards, presenter left, headline clear of the kicker, tags on their cards, step labels above the zone.
- **Also looked at in 16:9:** editorial-notebook, 3D presenter (dialogue captions), roblox and voxel stages, and the four inkbeat looks in both layouts.
- **Still open:** cards without a landscape shape yet (lists, evidence variants, phone frame) are centred and shrunk; overlays with a `y` outside the content area are scaled to the frame; the `headline` caption preset costs a quarter of the height in landscape.

## NEXT (not done yet, in this order)
1. **Make the 3D styles (inkbeat engine) a drop-in template** so every style uses the SAME pipeline (script, gates, voice, captions, mix, critics, QA): `Reel` composition + `InkShot` component reading `data/timeline.json`, `syncProject` picks the template by `pack.engine`, scaffold of an inkbeat storyboard, installer installs `renderers/inkbeat`. Today the inkbeat engine still runs by its own tools (`tools/ink/*`).
2. **Style Studio**: `tools/style_studio.mjs` (propose 4 look variants from a brief/reference as rendered stills, refine by instruction, approve into a style pack) + `docs/STYLE-GUIDE.md`; looks move from code into pack JSON.
3. **YouTube long-form package**: chapters, SRT, 1280x720 thumbnail, description for 16:9 projects; a `youtube` critic.
4. Run the layout critic on every style's example in both layouts; docs sweep (`docs/STYLES.md`, README index).
5. Final production check on all three OSes.

## Final pass (viral script editor, reference remake, assets, speed)
- **Viral script editor** (`tools/script_studio.mjs`, `tools/critics/viral.mjs`, `skills/viral-script`): every film starts from `script/viral-plan.json` (promise, three hooks, beats with time shares, open loops, emotion arc, overlay and sound plan, loop, CTA, share reason). The rubric scores hook length and pattern, filler, specificity, information rhythm, stakes, payoff, loop, CTA, emotional range. `selftest_viral.mjs` proves it flags a weak script and passes a strong one. All eleven example films now carry a plan; one of them (`accept-mixed`, 13-word hook) fails its rubric honestly and is left as a known weak script.
- **Reference to improved film, tested on one of your real reference videos** (`Always-think-ahead`, a 2D stickman couple comedy): `ingest` -> `blueprint.mjs` (cut grid, pace, camera, sound hits, scaled to your length) -> `twist.mjs --idea` -> `script_studio new --ref` -> a new film (`examples/showcase-reference-remake`, 18.2 s): same format (two stick figures arguing, a headline banner, a slow pull-out) with new content, 3 s shots instead of 6, a real Google Chrome Help page as proof, tied sound, two cast voices, a loop ending. Reference critic: pass; twist levers met.
- **Assets:** `tools/assets/fetch.mjs`: CC0 / public-domain photos from Wikimedia Commons (originals, size MEASURED after download, `--contact` makes a numbered thumbnail sheet to choose from) and music from Openverse, with licence, author and source recorded in `assets/manifest.json`; `shot.bgImage` renders a photo behind any card with a slow push-in, blur and a dark or light scrim; `assets_review` refuses an unlicensed or stretched photo and a highlight that does not match what the capture recorded. Free sound-effect packs and AI video models were not added: the procedural sound effects measure launch-grade (realness 0.83) and untested heavy models would not be honest to ship.
- **Your own style on a pack:** `style-overrides.json` in a project is deep-merged over the pack (colours, safe zone, effects, fonts); the pack stays untouched.
- **Speed:** all-cores-but-two rendering, per-shot cache, a 22 percent faster Lanczos export (`-preset faster`), stills of every shot before any long render (a minute instead of 15), `--estimate` previews. 3D remains the cost: about 3 minutes per shot without a GPU.
- **Bugs this pass found by looking and by tests:** a missing-glyph box in the comment box and checklist ticks (now drawn as SVG, in every film that used them), a stale `--estimate` preview analysed as "the film" (a shared `finalVideo()` now chooses; delivery builds delete stale previews), a Google page that answers HEAD with 404 (the research critic retries with GET), the keyword HIDE matching "hides", a card that waited for a late anchor and left an empty frame (`typeAnchor`), a 3D dialogue where both mouths moved (`speaker` now drives the right mouth), and an unparseable tool (`research/search.mjs`) that no test had caught (the self-test now parses every tool script).
- **Tech stack check (searched 2026):** Kokoro-82M stays the default narrator (Apache-2.0, CPU, most accurate on tricky text). Orpheus 3B (emotion tags) and Chatterbox (MIT, voice cloning) are more expressive but need a GPU or about 18 times the compute; they are the upgrade path through `audio-plan.voice.engine`, not shipped untested.

## Style from a reference image or video (added last)
- `skills/reference-style/SKILL.md` teaches an AI to READ a style (character anatomy with ratios, materials, lighting from evidence, lens from depth, set inventory, colour roles, post, and for video the pace and sound), map it to what the engine can do, say honestly what it cannot, and prove the film matches.
- `tools/reference/style_brief.mjs` measures the look (light side, background blur, warm/cool, vignette, grain, face framing, skin and hair colour) and writes a sheet with a hint on every field; `--validate` refuses empty, vague, unlooked or colourless sheets. `style_map.mjs` picks the closest pack, writes `style-overrides.json` from the measured values and prints a per-element fidelity table (exact / close / approximate / CANNOT) with needs-build items and twist options. `style_check.mjs` is the by-eye protocol; `critics/style.mjs` measures family and palette shift and writes `review/style-compare-<ref>.jpg` (reference left, film right).
- **Worked example:** the stylised 3D podcaster image the user supplied, written up as `skills/reference-style/example-podcast-3d.style-brief.json`. The mapper picks `stylized-3d-presenter`, rates hair as CANNOT (volumetric clumps) and the face as approximate (no film-grade glossy eyes), and lists the objects the engine lacks (award plaque, neon sign, monitor, boom mic). The image file itself was not available in the workspace, so that brief has no measured block; the measuring tools were tested on frames of our own renders.
- **Before/after proof:** applying the brief's recipe to one shot (new character, tighter portrait framing, shallow depth of field, vignette, cooler light) visibly changed the render.
- Bugs found on the way: OpenCV 5 ships without the Haar face detector (requirements now pin `<5`, and the tool degrades honestly); `preview_shots.mjs` drew STALE stills after a storyboard edit (it now rebuilds the timeline first); the installer's module probe broke on a version-pinned requirement.
- Limits: faces and hair are simpler than a film-studio render (the skill tells the AI to design the twist around that: hood, beanie or short cut); a still-image reference cannot give pacing or sound; "character swap" and "set swap" are confirmed by eye, only the palette shift is measured.

## Honest limits
- **4K is an upscale.** Lanczos (ffmpeg) is instant and sharp-edged but adds no detail. Vector text and cards look best from a native render (`--scale 2`, about 4x the time). 3D shots are rendered at 1080x1920 and upscaled.
- **Voice emotion is shaped prosody, not acting.** Kokoro has no emotion control: speed, pitch, level, pauses, tremor and edge change per emotion (measured by `selftest_voice.mjs`). Punctuation in `tts_text` helps. A human still decides whether it sounds right.
- **Listening:** `tools/audio/ears.py` (free, built in) cuts clips and a checklist and flags masked sounds and level jumps; `tools/audio/earshot.mjs` wraps the open-source earshot analyser (CPU, about 1.1 GB models) for sync, loudness arc and professional-film comparison. Both measure; neither judges taste. The flags they raised on these films are minor (a level drop where the voice ends, a quiet pop).
- **Presenter-style captions** are small and sit at the top (the pack's `dialogue` preset keeps the host's face clear). That is a pack decision, not a bug.
- **3D characters are procedural rigs**, not modelled assets: presenter hair is a helmet in extreme close-up, voxel eyes are large.
- **Tamper evidence, not security:** approvals are signed in a chain, so hand-editing `state.json` is detected. An agent that reads the source could recompute it. The receipt records who approved and with which quote.
- **Speed:** 2D films build in about 1 minute; a 3D shot costs about 3 minutes without a GPU. Rendering uses all cores but two. Shots are cached by content hash.

## Windows (first real run of install.ps1)
It needed six fixes, all of which Linux could never show: dynamic `import()` of `C:\...` paths needs a `file://` URL (cinematography check, frames critic, build_video sync step, two self-tests); `npm`/`npx` are `.cmd` files and need a shell; directory links need junctions (a symlink needs admin); the bundled ffprobe stand-in was a `.cmd` the doctor could not run, so the installer now installs a real ffmpeg + ffprobe (`static-ffmpeg`); the newest Python on the machine has no onnxruntime or av wheel, so the installer prefers Python 3.10 to 3.13 and prints the version and pip's reason on failure; a hard-coded `.venv/bin/python` in one self-test. Windows paths with spaces are not tested; use a project folder without spaces.

## Earshot on the showcase film (installed from earshot-main.zip, CPU, models cached)
Verdict "launch-grade": 21 of 23 metrics in range, 0 critical, 0 major. Loudness -14.3 LUFS, 93 percent of visual events have a sound within 100 ms, no dead air. After the stereo and sub-layer change in `mix.py`: stereo width went from -45.2 dB to -15.8 dB (range starts at -15.5) and the sub share from -20.4 to -19.5 dB (range starts at -17.7): both still "minor" because the procedural music has no real low end.

## Known false alarm
The `video` critic reports an "unplanned cut" at 8.67 s in `accept-voxel-explainer`. The frames show one continuous shot (a fast pull-back while the key spins); there is no cut. Treat that finding as fast motion, not a defect.

## Known and left as is
- `accept-mixed` hook is 13 words (5 s): the viral rubric flags it. Fixing it means re-rendering a 16-minute 3D film.
- The 3D acceptance films were rendered before the later renderer changes (background photo layer, speaker-driven mouths, tick glyphs, caption merge); none of those changes alter a film that does not use them, so they were not re-rendered.

## Not done
- A human listen to the voices and music (use `review/ears/listen/CHECKLIST.md`).
- Native 4K rendering as a default (kept optional because of cost).
- Per-style full-length sample films at 1080x1920 (the samples are 540x960).
