# Status: what is implemented, tested, and still open

"Tested" means a command was run and its output read. Nothing here is claimed from files alone. Updated after the production-toolkit pass (voice casting, 4K, twist, toolchain critic, 3D films, CI).

## Verified by running
- **Self-tests:** `node tools/selftest.mjs` (fast) and `--full`; pipeline gates `tools/selftest_pipeline.mjs` (57 checks); approval workflow `tools/selftest_state.mjs`; voice casting and emotion `tools/selftest_voice.mjs --full`; twist engine `tools/selftest_twist.mjs`.
- **Clean-room install on GitHub Actions** (`.github/workflows/clean-install.yml` in the repo that holds the zip): **Ubuntu, macOS and Windows all pass** install, doctor, self-tests and a real render (GitHub Actions, run on the final zip). The voice model download (340 MB) is skipped there; the voice is tested on Linux (`selftest_voice.mjs --full`).
- **All eight 3D / acceptance films rendered at 1080x1920 with real Kokoro voice, QA passing:** Roblox, voxel, mixed, and the Roblox / stickman / presenter story trio (about 15 to 18 minutes each on 8 CPU cores, software GL), plus the earlier software-demo and motion-explainer. Contact sheet of the 3D films was looked at. Films and critic reports: `output/acceptance/`.
- **Research critic** passes on every acceptance film: each ships `research.json` with real, reachable sources; invented numbers are labelled `opinion`.
- **Per-style previews:** all 11 style packs have `preview/motion.mp4` (3 s) and `preview/sample.mp4` (a whole film, 540x960 with sound) made from real renders (`tools/style_samples.mjs`). The samples for noir-3d, original-creatures, paper-atlas and voxel-studio are half-size renders of the shared example scripts in that style.
- **Showcase film `examples/showcase-dialogue` (22.9 s):** two characters (Leo male, Maya female) with seven different emotions, a real captured Chromium blog page as proof, mockups tied to words, events-tied sound. 8 shots rendered in about 1 minute; Lanczos 4K file 2160x3840 decodes cleanly; all 14 critic checks pass. Found and fixed by looking at its contact sheet (see CHANGELOG).
- **A fresh low-context agent test** (reads only AGENTS.md, tries to skip gates): approvals without `request`, delegated final, seal before approval and build before approval were refused. It found that a hand-edited `state.json` was trusted: fixed (signed approval chain), plus a misleading message and a missing `seal` usage line. The sub-agent runs on whatever model the host uses; I could not force a cheap model, so this proves the instructions and gates, not a specific model.

## Honest limits
- **4K is an upscale.** Lanczos (ffmpeg) is instant and sharp-edged but adds no detail. Vector text and cards look best from a native render (`--scale 2`, about 4x the time). 3D shots are rendered at 1080x1920 and upscaled.
- **Voice emotion is shaped prosody, not acting.** Kokoro has no emotion control: speed, pitch, level, pauses, tremor and edge change per emotion (measured by `selftest_voice.mjs`). Punctuation in `tts_text` helps. A human still decides whether it sounds right.
- **Listening:** `tools/audio/ears.py` (free, built in) cuts clips and a checklist and flags masked sounds and level jumps; `tools/audio/earshot.mjs` wraps the open-source earshot analyser (CPU, about 1.1 GB models) for sync, loudness arc and professional-film comparison. Both measure; neither judges taste. The flags they raised on these films are minor (a level drop where the voice ends, a quiet pop).
- **Presenter-style captions** are small and sit at the top (the pack's `dialogue` preset keeps the host's face clear). That is a pack decision, not a bug.
- **3D characters are procedural rigs**, not modelled assets: presenter hair is a helmet in extreme close-up, voxel eyes are large.
- **Tamper evidence, not security:** approvals are signed in a chain, so hand-editing `state.json` is detected. An agent that reads the source could recompute it. The receipt records who approved and with which quote.
- **Speed:** 2D films build in about 1 minute; a 3D shot costs about 3 minutes without a GPU. Rendering uses all cores but two. Shots are cached by content hash.

## Windows (first real run of install.ps1)
It needed six fixes, all of which Linux could never show: dynamic `import()` of `C:\...` paths needs a `file://` URL (cinematography check, frames critic, build_video sync step, two self-tests); `npm`/`npx` are `.cmd` files and need a shell; directory links need junctions (a symlink needs admin); the bundled ffprobe stand-in was a `.cmd` the doctor could not run, so the installer now installs a real ffmpeg + ffprobe (`static-ffmpeg`); the newest Python on the machine has no onnxruntime or av wheel, so the installer prefers Python 3.10 to 3.13 and prints the version and pip's reason on failure; a hard-coded `.venv/bin/python` in one self-test. Windows paths with spaces are not tested; use a project folder without spaces.

## Earshot on the showcase film (installed from earshot-main.zip, CPU, models cached)
Verdict "launch-grade": 21 of 23 metrics in range, 0 critical, 0 major. Loudness -14.3 LUFS, 93 percent of visual events have a sound within 100 ms, no dead air. After the stereo and sub-layer change in `mix.py`: stereo width went from -45.2 dB to -15.8 dB (range starts at -15.5) and the sub share from -20.4 to -19.5 dB (range starts at -17.7): both still "minor" because the procedural music has no real low end.

## Known false alarm
The `video` critic reports an "unplanned cut" at 8.67 s in `accept-voxel-explainer`. The frames show one continuous shot (a fast pull-back while the key spins); there is no cut. Treat that finding as fast motion, not a defect.

## Not done
- A human listen to the voices and music (use `review/ears/listen/CHECKLIST.md`).
- Native 4K rendering as a default (kept optional because of cost).
- Per-style full-length sample films at 1080x1920 (the samples are 540x960).
