# The inkbeat 3D engine inside the normal pipeline

The inkbeat engine (`renderers/inkbeat`, React Three Fiber toon shading, painted textures, ink outlines, a camera that is never still) is now one engine of the SAME build. A film in an inkbeat pack (`inkbeat`, `kidsong-3d`, `zackd-cutaway`, `anime-cinematic`, `pixar-soft`) uses the same intake, style, script, viral editor, storyboard, assets, voice, word timing, captions timing, sound cues, mix, per-shot cache, assemble, loudness, QA, critics, YouTube package and gates as every other film. Only the pictures are drawn by this engine.

## How it plugs in
1. The storyboard shots use `component: "InkShot"` (a marker; `approach` `character-3d` or `physical-3d`). Everything else in the storyboard is unchanged: line ids, anchors, sfx, transitions.
2. `tools/build_video.mjs` reads `style-packs/<pack>/style.json` `engine`. For `inkbeat` it runs `tools/ink/scaffold_plan.mjs` once (an `ink-plan.json` skeleton from the storyboard and the real word times), `tools/ink/plan.mjs` (resolves the beats to words and prints the pacing report) and `tools/ink/render_segments_ink.mjs` instead of `render_segments.mjs`. Same cache (`renders/segments/<shot>-<hash>.mp4`), same `index.json`, so `assemble.mjs` runs unchanged.
3. `tools/preview_shots.mjs` draws the review stills with the ink engine (15, 50 and 90 percent of every shot; the 50 percent one is the frame the user approves): the storyboard gate shows images, as for every engine.
4. The look is `plan.look`: `den` (the original den and adult hero), `kidsong`, `zackd`, `anime`, `pixar` (each has its own set, hero, outline strength and sky; the scaffold picks it from the pack). The camera grammar is the common one (`docs/CAMERA-GRAMMAR.md`; cadence profile from the pack).

## Commands
```
bash install.sh --with-inkbeat                              # npm install in renderers/inkbeat (about 300 MB)
node tools/ink/scaffold_plan.mjs <P>                        # skeleton ink-plan.json (after the voice: build_video --estimate gives estimated words)
node tools/preview_shots.mjs <P>                            # stills to approve (storyboard gate)
node tools/build_video.mjs <P> --scale 0.25                 # a cheap preview; the master once the plan is approved
```
Improve the plan by hand (`skills/inkbeat`, `skills/inkbeat/references/camera-and-editing.md`): sets, hero position and acting (`acts`), lens (`preset` or `aim`), moves on words (`beats`), tags on objects (`show.tags`).

## Cost and limits (measured, honest)
- Software GL: about 15 s per 1080x1920 still, so a 30 s film is hours on a CPU. A GPU makes it minutes. Iterate with `--scale 0.25` and stills; render the master once; interrupted renders resume from the cache.
- Sets are code (`src/story/Den.tsx`, `src/looks/Sets.tsx`): a new location is new code. The four looks are moods plus a set each; a brand-new 3D look is still a code change (see `docs/STYLE-GUIDE.md`, "A new 3D look").
- The Style Studio proposes 2D and Stage3D looks as stills; it does not propose a new inkbeat look.


## A 3D look is data: `ink_look` in a style pack
A new 3D look needs no code. The Style Studio writes `ink_look` into the pack; `tools/ink/scaffold_plan.mjs` copies it into `ink-plan.json` as `lookSpec`; the renderer builds it (`renderers/inkbeat/src/looks/custom.tsx`). Check one with `node tools/ink/look_check.mjs <style.json>`.
```
"ink_look": {
  "ink": 0..1,               // outline strength on characters (0 = none: clay, kids, storybook)
  "sky": true,               // draw the sky dome (false for a studio or interior)
  "blur": 1.4,               // depth-of-field strength
  "moods": { "main": { "base": "lamp|day|dusk|night|cold|golden|kids-day|zd-studio|anime-day|pixar-warm|...", "patch": { /* deep merge into the mood: lights, fog, sky, toon{ramp: cel|smooth|clay}, post{outline, bloom, grade, vignette, dof}, camFill */ } } },
  "hero": { "base": "kidsong|zackd|anime|pixar", "height": 1.7, "look": { "hair": "...", "hairColor": "#..", "colors": { "top": "#..", "bottom": "#..", "shoes": "#..", "accent": "#.." } } },
  "set": { "preset": "playroom|studio|street|kitchen" }
       // OR a set from primitives:
       { "floor": {"c":"#..","tex":"stone","size":[18,14]}, "walls": {"c":"#..","sides":["back"],"h":4}, "ceiling": "#..",
         "props": [ {"k":"box|round|cyl|sph|cone|tor|glow|label", "s":[..], "p":[x,y,z], "r":[..], "c":"#..", "tex":"wood|stone|fabric|...", "e":"#.. (emissive)", "ei":0.4, "anim":"bob|spin|sway", "repeat":{"n":6,"step":[dx,dy,dz],"colors":["#..",".."]}} ],
         "lights": [ {"p":[x,y,z],"color":"#..","intensity":3,"distance":8} ] }
}
```
Facts learned from the first Studio-made look (`lantern-market-3d`), so the next one is faster:
- Compose the set for the frame shape: in 9:16 the wide shot sees only about +-2.5 m across at the hero's depth. A prop at x = 3.3 is off screen. Put the story's key object on the camera axis.
- The key fact of the story must be an object in the set (a queue for "the queue is the ad"). Put it in the set before the film, then author a shot that looks at it (`cam.aim`).
- Bright saturated colours on lit surfaces wash to cream under a clay highlight. A glowing thing (lantern, sign, window) is a `glow` prop at k2 0.7-0.8 (unlit, below the bloom threshold), not a lit sphere with emissive. k2 above 1 blooms to white.
- A point light closer than about 1 m to a surface blows it out. Keep practicals 1.5 m or more from what they light.
- Four looks that share one set and differ only in the sky are one look. Change the set palette, the key colour and the shading ramp (the Studio warns when two variants differ by under 9 percent).
- Background people are bodies and blank heads: fine for a queue, not for a close-up. A shot that needs a face needs a hero.
