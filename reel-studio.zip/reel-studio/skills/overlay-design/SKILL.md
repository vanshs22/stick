---
name: overlay-design
description: Design overlays, cards, labels, counters, badges, screenshots and real B-roll that look professional: where, when, how big, tied to which word. Use when writing the storyboard's overlays and when a shot feels cluttered or flat.
---
# Overlay design
Read `docs/OVERLAY-GRAMMAR.md` (measured from seven reference reels: the ten rules, the recipe table, the budget) and `docs/LONGFORM-LANDSCAPE.md` (roles: dock, strip, card, free).
Budget: at most 4 overlays at once, each on a word (`anchor`), one hero per shot, under about 15 percent of the frame, text at least 28 px. Real evidence for claims: `tools/capture/capture_web.mjs` (screenshots) or `record_broll.mjs` (moving B-roll with cursor and zoom) + `ProofCard` / `Footage`.
Measure a reference: `python tools/reference/overlay_scan.py <video>`; check yours in both shapes: `node tools/layout_lab.mjs --aspect both`.
