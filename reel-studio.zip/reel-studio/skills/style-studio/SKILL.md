---
name: style-studio
description: Turn "make it in <some look>" into an approved style pack by showing rendered choices first, refining on the user's words, and only then starting the normal film pipeline. Use when the user asks for a new or different visual style (realistic 3D, chalkboard, neon, clay, anything) or wants to compare looks.
---

# Style Studio (agent instructions)

Read `docs/STYLE-GUIDE.md` section 2 and follow it. Short form:
1. One sentence brief. A reference image or video? Read `skills/reference-style/SKILL.md` first.
2. Closest 2D/Stage3D base pack (`tools/gallery.mjs`). For a new 3D look on the inkbeat engine read section 4 of the guide and say plainly that it is code.
3. Write 4 DIFFERENT looks in `variants.json`; `node tools/style_studio.mjs propose <name> --brief "..." --base <pack> --aspect 16:9|9:16 --variants variants.json`.
4. Open `choices.jpg` yourself. Fix what you can see (unreadable text, low contrast, two accents) before the user sees it.
5. Show it, ask ONE question: which look, or what to change. STOP. `refine` on their words, repeat.
6. `approve ... --quote "<their exact words>"`. Never approve for them.
7. `choose.mjs <project> style <id>`, then continue with `next.mjs`: the script, gates, voice, captions, camera and critics are the same for every style.

Never: start the script before a look is approved; say a look is good without opening the image; copy an existing character, logo or distinctive design from a reference; claim the Studio can make a shape it cannot (new card types and new 3D character models are code).
