import style from '../data/style.json';
import timeline from '../data/timeline.json';

import typo from '../data/typography.json';
import {fontFamily} from './fonts';

// fonts come from typography/typography.json (chosen by the user at the typography gate); defaults keep the old look
export const TYPO = typo as any;
export const F = {serif: fontFamily(TYPO.supporting?.font || 'InstrumentSerif'), sans: fontFamily(TYPO.headline?.font || 'Inter'), mono: fontFamily(TYPO.ui?.font || 'JetBrainsMono'), caption: fontFamily(TYPO.caption?.font || TYPO.headline?.font || 'Inter')};
export const C = {...(style as any).colors} as Record<string, string>;
export const W: number = (timeline as any).width || 1080;
export const H: number = (timeline as any).height || 1920;
/** the frame is landscape (16:9 long-form): px authored on the 1080x1920 portrait canvas are scaled, the content zone and captions move (SAFE below) */
export const LANDSCAPE = W > H;
const SZ = (style as any).safe_zone || {};
/** safe zones in px of THIS frame. Portrait: style.json safe_zone (authored on 1080x1920). Landscape: derived from the height (content above the caption band, margins at the sides), a pack may override with safe_zone_landscape; with a presenter the cards take the right 60 percent */
export const SAFE = LANDSCAPE
  ? {top: Math.round(H * 0.07), bottom: Math.round(H * 0.93), caption_y: Math.round(H * 0.8), right_margin: Math.round(W * 0.08), content_top: Math.round(H * 0.08), content_bottom: Math.round(H * 0.78), content_left: (style as any).presenter ? Math.round(W * 0.4) : 0, ...((style as any).safe_zone_landscape || {})}
  : {top: 180, bottom: 1380, caption_y: 1440, right_margin: 120, content_top: 180, content_bottom: 1380, content_left: 0, ...SZ};
/** x, y of a px position authored on the 1080x1920 canvas, in this frame */
export const fx = (x: number) => (x * W) / 1080;
export const fy = (y: number) => (y * H) / 1920;
/** window chrome of the pack: 'clean' (soft shadow), 'sticker' (thick outline + hard shadow), 'glass' (dark translucent panel) */
export const CHROME: string = (style as any).chrome || 'clean';
/** named background colours a shot can switch to with `bg` (ref6 changes colour per section) */
export const BGS: Record<string, string> = {paper: C.bg, ...((style as any).bgs || {})};
export const PRESENTER = (style as any).presenter as undefined | Record<string, any>;
export const CAPTION = {fill: '#fff', stroke: 'rgba(8,8,20,0.92)', ...((style as any).caption || {})} as {fill: string; stroke: string};
export const STYLE_ID: string = (style as any).id;
